chrome.browserAction.onClicked.addListener(function(tab) {
	chrome.tabs.query({active: true}, function(tabs){ 
		chrome.tabs.sendMessage(tab.id, {
			action: "open_dialog_box"
		}, function(response) { }); 
	});
});