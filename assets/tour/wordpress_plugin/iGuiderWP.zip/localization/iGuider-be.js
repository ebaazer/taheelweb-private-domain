﻿/* Belarusian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'be',
		cancelText: '×',
		cancelTitle: 'Адмяніць',
		hideText: 'Схаваць',
		tourMapText:'≡',
		tourMapTitle: 'Карта тура',
		nextTextDefault:'Наст.',
		prevTextDefault:'Папяр.',
		endText:'Скончыць',

		modalIntroType:'Ўвядзенне',
		modalContinueType:'Няпоўны тур',
		
		
		contDialogBtnBegin:'Пачаць з пачатку',
		contDialogBtnContinue:'Працягнуць',
		 							
			
		introDialogBtnStart:'Старт',											
		introDialogBtnCancel:'Адмена'
	}
});