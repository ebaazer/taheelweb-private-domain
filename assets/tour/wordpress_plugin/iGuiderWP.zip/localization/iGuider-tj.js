﻿/* Tajiki Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'tj',
		cancelText: '×',
		cancelTitle: 'Бекор кардан',
		hideText: 'Пинҳон кардан',
		tourMapText:'≡',	
		tourMapTitle: 'Харитаи саёҳат',
		nextTextDefault:'Баъдӣ',	
		prevTextDefault:'Гузашта',	
		endText:'Анҷоми саёҳат',

		modalIntroType:'Дохил шудан',
		modalContinueType:'Сафари тамомнашуда',
		
		
		contDialogBtnBegin: 'Оғози аз аввали ',
		contDialogBtnContinue: "Идома",
		 							
			
		introDialogBtnStart:'Оғоз кунед',											
		introDialogBtnCancel:'Бекор кардан'
	}
});