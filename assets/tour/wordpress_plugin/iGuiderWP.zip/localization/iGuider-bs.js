﻿/* Bosnian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'bs',
		cancelText: '×',
		cancelTitle:	'Otkazivanje',
		hideText: 'Sakriti',
		tourMapText:'≡',
		tourMapTitle: 'Tour Karta',
		nextTextDefault:'Sljedeći',
		prevTextDefault:'Prethodna',
		endText:'Zzavršiti',

		modalIntroType:'Intro',
		modalContinueType:'Nedovršena tura.',
		
		
		contDialogBtnBegin:'Počnite od početka',
		contDialogBtnContinue:'Nastavi',
		 							
			
		introDialogBtnStart:'Počni',											
		introDialogBtnCancel:'Otkaži'
	}
});