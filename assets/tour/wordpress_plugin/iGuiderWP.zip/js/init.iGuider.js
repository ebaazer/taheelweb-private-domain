﻿/*
 * jQuery iGuider init 
 */
 
/*

*/
/*This is plugin options*/
var opt = {
    'tourID': 'anyTourID',
    'tourTitle': 'Tour Title Default',
    'startStep': '1',
    'overlayClickable': true,
    'overlayColor': '#000',
    'overlayOpacity': '0.5',
    'pagination': true,
    'registerMissingElements': true,
    'textDirection': 'ltr',
	'shape':0,
	'shapeBorderRadius':5,
	'width':320,
	'bgColor':false,
	'titleColor':false,
	'modalContentColor':false,
	'modalTypeColor':false,
	'paginationColor':false,
	'timerColor':false,
	'btnColor':false,
	'btnHoverColor':false,
	'spacing':10,
	'loc':false,
	'timer':false,
	'timerType':'line',
	'keyboard':true,
	'keyboardEvent':false,
    'intro': {
        'enable': true,
        'cover': '',
		'title':'Welcome to the interactive tour',
		'content':'This tour will tell you about the main site functionalities',	
        'overlayColor': false,
        'overlayOpacity': false,
		'width':false,
		'bgColor':false,
		'titleColor':false,
		'modalContentColor':false,
		'modalTypeColor':false,
		'btnColor':false,
		'btnHoverColor':false
    },
    'continue': {
        'enable': true,
        'cover': '',
		'title':'Continue the unfinished tour?',
		'content':'Click "Continue" to start with step on which finished last time.',
        'overlayColor': false,
        'overlayOpacity': false,
		'width':false,
		'bgColor':false,
		'titleColor':false,
		'modalContentColor':false,
		'modalTypeColor':false,
		'btnColor':false,
		'btnHoverColor':false
    },
    'tourMap': {
        'enable': true,
        'position': 'right',
        'clickable': true,
        'open': false,
		'bgColor':false,
		'titleColor':false,
		'btnColor':false,
		'btnHoverColor':false,
		'itemColor':false,
		'itemHoverColor':false,
		'itemActiveColor':false,
		'itemActiveBg':false,
		'itemNumColor':false,
		'checkColor':false,
		'checkReadyColor':false
    },
    'lang': {
        'cancelTitle': 'Cancel Tour',
        'cancelText': '×',
        'hideText': 'Hide Tour Map',
        'tourMapText': '≡',
        'tourMapTitle': 'Tour Map',
        'nextTextDefault': 'Next',
        'prevTextDefault': 'Prev',
        'endText': 'End Tour',
        
        'contDialogBtnBegin': 'Start from beginning',
        'contDialogBtnContinue': 'Continue',
        
        'introDialogBtnStart': 'Start',
        'introDialogBtnCancel': 'Cancel'
    },
    'steps': [
        {
			'cover': '',
            'title': 'New Step Title 1',
            'content': 'New Step Description 1',
			'position': 'auto',
            'target': '',
			'disable': false,
            'overlayOpacity': '0.5',
            'overlayColor': '#000',
            'spacing': '10',
            'shape': '0',
            'shapeBorderRadius': '5',
            'duration': '300',
            'timer': '4000',
            'event': 'next',
			'eventMessage':'Follow the required conditions to continue.',
            'skip': false,
            'nextText': 'Next',
            'prevText': 'Prev',
            'trigger': false,
            'stepID': '',
			'waitElementTime':'0',
            'loc': false,
			'ready':false,
			'width':'320px',
			'autofocus':true,
			'keyboardEvent':false,
			'bgColor':false,
			'titleColor':false,
			'modalContentColor':false,
			'paginationColor':false,
			'timerColor':false,
			'btnColor':false,
			'btnHoverColor':false,
			'checkNext':{
				'func':function(){return true},
				'messageError':'Fulfill all the conditions!'
			},
            'delayBefore': '0',
            'delayAfter': '0'
        },
        {
			'cover': '',
            'title': 'New Step Title 2',
            'content': 'New Step Description 2',
			'position': 'auto',
            'target': '',
			'disable': false,
            'overlayOpacity': '0.5',
            'overlayColor': '#000',
            'spacing': '10',
            'shape': '0',
            'shapeBorderRadius': '5',
            'duration': '300',
            'timer': '4000',
            'event': 'next',
            'skip': false,
            'nextText': 'Next',
            'prevText': 'Prev',
            'trigger': false,
            'stepID': '',
            'waitElementTime':'0',
            'loc': false,
			'ready':false,
			'width':'320px',
			'checkNext':{
				'func':function(){return true},
				'messageError':'Fulfill all the conditions!'
			},
            'delayBefore': '0',
            'delayAfter': '0'
        }
    ]
};

/*This is plugin call*/
jQuery(window).on('load',function(){
    iGuider('button',opt);
});