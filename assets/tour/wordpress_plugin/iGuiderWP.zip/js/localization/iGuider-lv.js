﻿/* Latvian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'lv',
		cancelText: '×',
		cancelTitle:	'Atcelt',
		hideText: 'Slēpt',
		tourMapText:'≡',	
		tourMapTitle: 'Karte ceļojums',
		nextTextDefault:'Nākamais',	
		prevTextDefault:'Iepriekšējais',	
		endText:'Done',
		contDialogTitle: 'Turpināt iesākto ceļojumu?',
		contDialogContent: 'noklikšķiniet uz "Turpināt", lai sāktu ar soli uz kuras gatavo pēdējo reizi.',
		contDialogBtnBegin: 'Sākt no sākuma',
		contDialogBtnContinue: 'Turpināt',
		introTitle:'Laipni lūdzam interaktīvā ceļojumā.', 							
		introContent:'Šajā ceļojumā tiks pastāstīts par galvenajām vietnes funkcijām.',	
		introDialogBtnStart:'Sākt',											
		introDialogBtnCancel:'Atcelt'
	}
});