﻿/* Armenian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'hy',
		cancelText: '×',
		cancelTitle:	'վերացնել',
		hideText: 'թաքցնել',
		tourMapText:'≡',	
		tourMapTitle: 'Քարտեզ',
		nextTextDefault:'հաջ',	
		prevTextDefault:'Նախ.',	
		endText:'Վերջ տուր',
		contDialogTitle: 'Շարունակել անավարտ շրջագայությունը.',
		contDialogContent: 'Սեղմեք "Շարունակել" սկսել քայլ որն ավարտվել վերջին անգամ.',
		contDialogBtnBegin: 'Սկսել սկզբից',
		contDialogBtnContinue: 'Շարունակել',
		introTitle:'Բարի գալուստ ինտերակտիվ տուր:', 							
		introContent:'Այս շրջագայությունը ձեզ կտեղեկացնի հիմնական կայքի գործառույթների մասին:',	
		introDialogBtnStart:'Սկսեք',											
		introDialogBtnCancel:'Չեղարկել'
	}
});