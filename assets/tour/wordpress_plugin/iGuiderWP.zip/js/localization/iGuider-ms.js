﻿/* Malaysian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ms',
		cancelText: '×',
		cancelTitle: 'Tutup',
		hideText: 'Bersembunyi',
		tourMapText:'≡',	
		tourMapTitle: 'Peta tour',
		nextTextDefault:'Selepas',	
		prevTextDefault:'Sebelum',	
		endText:'Matang',
		contDialogTitle:'Meneruskan lawatan belum selesai?',
		contDialogContent:'Klik "Teruskan" untuk memulakan dengan langkah yang selesai masa lalu.',
		contDialogBtnBegin:'Bermula dari awal',
		contDialogBtnContinue:'Teruskan',
		introTitle:'Selamat datang ke lawatan interaktif.', 							
		introContent:'Lawatan ini akan memberitahu anda mengenai fungsi laman web utama.',	
		introDialogBtnStart:'Mulakan',											
		introDialogBtnCancel:'Batalkan'
	}
});