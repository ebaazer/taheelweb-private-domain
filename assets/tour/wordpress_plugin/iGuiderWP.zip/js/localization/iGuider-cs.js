﻿/* Czech Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'cs',
		cancelText: '×',
		cancelTitle:	'Kantsel',
		hideText: 'Skrýt',
		tourMapText:'≡',
		tourMapTitle: 'Mapa turné',
		nextTextDefault:'Později',
		prevTextDefault:'Dříve',
		endText:'Konec',
		contDialogTitle:'Pokračujte nedokončený turné?',
		contDialogContent:'Klikněte na "Pokračovat" začít s krokem, na kterém skončil minule.',
		contDialogBtnBegin:'Začít od začátku',
		contDialogBtnContinue:'Pokračovat',
		introTitle:'Vítejte na interaktivní prohlídce.', 							
		introContent:'Toto turné vám povědí o hlavních funkcích webu.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Zrušení'
	}
});