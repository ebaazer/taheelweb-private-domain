﻿/* Azerbaijani Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'az',
		cancelText: '×',
		cancelTitle:	'Ləğv etmək',
		hideText: 'Gizləmək',
		tourMapText:'≡',
		tourMapTitle: 'Tur Map',
		nextTextDefault:'İrəli',
		prevTextDefault:'Geri',
		endText:'Finiş',
		contDialogTitle:'Yarımçıq tur davam?',
		contDialogContent:'Click olan son dəfə başa addım başlamaq üçün "Davam et".',
		contDialogBtnBegin:'Əvvəldən başlamaq',
		contDialogBtnContinue:'Davam etdirmək',
		introTitle:'İnteraktiv tura xoş gəlmisiniz.', 							
		introContent:'Bu tur əsas saytın funksiyaları haqqında sizə məlumat verəcəkdir.',	
		introDialogBtnStart:'Başlamaq',											
		introDialogBtnCancel:'Ləğv et'
	}
});