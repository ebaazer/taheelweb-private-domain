﻿/* Bosnian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'bs',
		cancelText: '×',
		cancelTitle:	'Otkazivanje',
		hideText: 'Sakriti',
		tourMapText:'≡',
		tourMapTitle: 'Tour Karta',
		nextTextDefault:'Sljedeći',
		prevTextDefault:'Prethodna',
		endText:'Zzavršiti',
		contDialogTitle:'Nastaviti nedovršena turneju?',
		contDialogContent:'Kliknite na "Nastavi" za početak korak na koji je završio prošli put.',
		contDialogBtnBegin:'Počnite od početka',
		contDialogBtnContinue:'Nastavi',
		introTitle:'Dobrodošli na interaktivnu turneju.', 							
		introContent:'Ova tura će vam reći o funkcijama glavnog sajta.',	
		introDialogBtnStart:'Počni',											
		introDialogBtnCancel:'Otkaži'
	}
});