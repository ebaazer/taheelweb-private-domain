﻿/* Kyrgyz Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ky',
		cancelText: '×',
		cancelTitle:	'Жабуу',
		hideText: 'Жашыруу',
		tourMapText:'≡',	
		tourMapTitle: 'Турдун карта',
		nextTextDefault:'Кийинки',	
		prevTextDefault:'Мурунку',	
		endText:'Даяр',
		contDialogTitle: 'Бүтпөгөн сапарын уланта?',
		contDialogContent: 'Акыркы жолу бүтүп турган кадам менен баштоо үчүн "Улантуу" чыкылдатуу.',
		contDialogBtnBegin: 'Башынан баштоо',
		contDialogBtnContinue: 'Улантуу',
		introTitle:'өз ара аракеттенүү сапарынын кош.', 							
		introContent:'Бул сапары негизги сайт functionalities жөнүндө айтып берет',	
		introDialogBtnStart:'Баштоо',											
		introDialogBtnCancel:'Алууну жокко'
	}
});