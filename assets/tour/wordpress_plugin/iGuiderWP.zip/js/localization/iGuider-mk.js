﻿/* Macedonian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'mk',
		cancelText: '×',
		cancelTitle:	'Затвори',
		hideText: 'Крие',
		tourMapText:'≡',	
		tourMapTitle: 'Мапа на турнеја',
		nextTextDefault:'Следна',	
		prevTextDefault:'Претходно',	
		endText:'Крајот турнеја',
		contDialogTitle: 'Продолжи недовршени турнеја? ',
		contDialogContent: 'Кликнете на "Продолжи" за да започне со чекор на кој заврши последен пат. ',
		contDialogBtnBegin: 'Започнете од почеток',
		contDialogBtnContinue: 'Продолжи',
		introTitle:'Добредојдовте во интерактивната тура.', 							
		introContent:'Оваа турнеја ќе ви каже за функционалностите на главниот сајт.',	
		introDialogBtnStart:'Започнете',											
		introDialogBtnCancel:'Откажи'
	}
});