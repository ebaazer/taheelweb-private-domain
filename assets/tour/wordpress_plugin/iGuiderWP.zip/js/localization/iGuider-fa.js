﻿/* Persian (Farsi) Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'fa',
		cancelText: '×',
		cancelTitle:	'لغو کردن',
		hideText: 'پنهان شدن',
		tourMapText:'≡',	
		tourMapTitle: 'تور نقشه',
		nextTextDefault:'بعد',	
		prevTextDefault:'قبلی',	
		endText:'پایان',
		contDialogTitle: 'ادامه تور ناتمام؟',
		contDialogContent: 'کلیک کنید "ادامه" را با قدم اول که به پایان رسید زمان آخرین شروع می شود.',
		contDialogBtnBegin: 'شروع از ابتدا',
		contDialogBtnContinue: 'ادامه',
		introTitle:'به تور تعاملی خوش آمدید', 							
		introContent:'این تور به شما در مورد ویژگی های سایت اصلی می گوید.',	
		introDialogBtnStart:'شروع کنید',											
		introDialogBtnCancel:'لغو'
	}
});