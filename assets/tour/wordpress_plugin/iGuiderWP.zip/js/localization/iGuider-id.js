﻿/* Indonesian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'id',
		cancelText: '×',
		cancelTitle:	'Batalkan',
		hideText: 'Bersembunyi',
		tourMapText:'≡',	
		tourMapTitle: 'Peta tour',
		nextTextDefault:'Berikutnya',	
		prevTextDefault:'Sebelumnya',	
		endText:'Tur akhir',
		contDialogTitle: 'Lanjutkan tur yang belum selesai?',
		contDialogContent: 'Klik "Lanjutkan" untuk memulai dengan langkah yang selesai terakhir kali.',
		contDialogBtnBegin: 'Mulai dari awal',
		contDialogBtnContinue: 'Lanjutkan',
		introTitle:'Selamat datang di tur interaktif.', 							
		introContent:'Tur ini akan bercerita tentang fungsi situs utama.',	
		introDialogBtnStart:'Mulai',											
		introDialogBtnCancel:'Batal'
	}
});