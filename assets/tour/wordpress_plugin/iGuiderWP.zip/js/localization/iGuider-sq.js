﻿/* Albanian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'sq',
		cancelText: '×',
		cancelTitle:	'Anuloj',
		hideText: 'Fsheh',
		tourMapText:'≡',	
		tourMapTitle: 'Harta e turneut',
		nextTextDefault:'Tjetër',	
		prevTextDefault:'Prapa',	
		endText:'Turneu End',
		contDialogTitle: 'Vazhdo turne papërfunduar?',
		contDialogContent: 'Kliko "Vazhdo" për të filluar me hap në të cilën përfundoi për herë të fundit.',
		contDialogBtnBegin: 'Filloni nga fillimi ',
		contDialogBtnContinue: 'Vazhdo',
		introTitle:'Mirë se vini në turneun interaktiv.', 							
		introContent:'Ky turne do t\'ju tregojë për funksionalitetet kryesore të faqes.',	
		introDialogBtnStart:'Filloni',											
		introDialogBtnCancel:'Anulluar'
	}
});