﻿/* Ukrainian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'uk',
		cancelText: '×',
		cancelTitle:	'Перервати',
		hideText: 'Сховати карту',
		tourMapText:'≡',	
		tourMapTitle: 'Карта туру',
		nextTextDefault:'Далі',	
		prevTextDefault:'Назад',	
		endText:'Закінчити тур',
		contDialogTitle: 'Продовжити незакінчений тур?',
		contDialogContent: 'Натисніть кнопку "Продовжити", щоб почати з кроку, на якому закінчили минулого разу.',
		contDialogBtnBegin: 'Почати з початку',
		contDialogBtnContinue: 'Продовжити',
		introTitle:'Ласкаво просимо до інтерактивного туру.', 							
		introContent:'Ця поїздка розповість вам про основні функціональні можливості сайту.',	
		introDialogBtnStart:'Почати',										
		introDialogBtnCancel:'Скасувати'
	}
});