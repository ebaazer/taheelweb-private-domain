﻿/* Slovenian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'sl',
		cancelText: '×',
		cancelTitle: 'Prekliči',
		hideText: 'Skrij',
		tourMapText:'≡',	
		tourMapTitle: 'Zemljevid turneji',
		nextTextDefault:'Naslednji',	
		prevTextDefault:'Prejšnja',	
		endText:'Končano',
		contDialogTitle: 'Nadaljujemo z nedokončano turnejo?',
		contDialogContent: 'Kliknite "Naprej", da začnete s korakom, na katerih končal zadnjič.',
		contDialogBtnBegin: 'Začni od začetka',
		contDialogBtnContinue: 'Naprej',
		introTitle:'Dobrodošli na interaktivni turneji.', 							
		introContent:'Ta turneja vam bo povedala o glavnih funkcionalnostih spletnih mest.',	
		introDialogBtnStart:'Začni',											
		introDialogBtnCancel:'Prekliči'
	}
});