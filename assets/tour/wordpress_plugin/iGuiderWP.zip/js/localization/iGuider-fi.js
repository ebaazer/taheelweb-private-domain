﻿/* Finnish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'fi',
		cancelText: '×',
		cancelTitle:	'Peruuttaa',
		hideText: 'Piilottaa',
		tourMapText:'≡',	
		tourMapTitle: 'Tour kartta',
		nextTextDefault:'Seuraava',	
		prevTextDefault:'Edellinen',	
		endText:'Pää',
		contDialogTitle: 'Jatka keskeneräiset kiertueen?',
		contDialogContent: 'Valitse "Jatka" aloittaa vaiheesta, johon valmiiksi viime kerralla.',
		contDialogBtnBegin: 'Aloita alusta',
		contDialogBtnContinue: 'Jatka',
		introTitle:'Tervetuloa interaktiiviseen kiertueeseen.', 							
		introContent:'Tämä kiertue kertoo tärkeimmistä sivuston toiminnoista.',	
		introDialogBtnStart:'Alkaa',											
		introDialogBtnCancel:'Peruuttaa'
	}
});