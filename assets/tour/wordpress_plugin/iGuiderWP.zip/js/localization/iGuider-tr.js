﻿/* Turkish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'tr',
		cancelText: '×',
		cancelTitle:	'İptal etmek',
		hideText: 'Gizlemek',
		tourMapText:'≡',	
		tourMapTitle: 'Harita turu',
		nextTextDefault:'Ileri',	
		prevTextDefault:'Geri',	
		endText:'End tur',
		contDialogTitle: 'bitmemiş turu devam edilsin mi?',
		contDialogContent: 'Geçen sefer bitmiş hangi adımla başlamak için "Devam" ı tıklayın.',
		contDialogBtnBegin: 'baştan başla',
		contDialogBtnContinue: 'Devam',
		introTitle:'Etkileşimli tura hoş geldiniz.', 							
		introContent:'Bu tur ana site işlevleri hakkında bilgi verecektir.',	
		introDialogBtnStart:'Başla',											
		introDialogBtnCancel:'İptal etmek'
	}
});