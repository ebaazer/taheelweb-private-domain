﻿/* Polish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'pl',
		cancelText: '×',
		cancelTitle:	'Anuluj',
		hideText: 'Ukryć',
		tourMapText:'≡',	
		tourMapTitle: 'Mapa trasy',
		nextTextDefault:'Następny',	
		prevTextDefault:'Poprzedni',	
		endText:'Gotowe',
		contDialogTitle: 'Kontynuować niedokończone wycieczkę?',
		contDialogContent: 'kliknij "Kontynuuj", aby rozpocząć od kroku, na którym ukończył ostatni raz.',
		contDialogBtnBegin: 'Zacznij od początku',
		contDialogBtnContinue: 'Kontynuuj',
		introTitle:'Witamy w interaktywnej wycieczce.', 							
		introContent:'Podczas tej wycieczki dowiesz się o głównych funkcjach witryny.',	
		introDialogBtnStart:'Początek',											
		introDialogBtnCancel:'Anuluj'
	}
});