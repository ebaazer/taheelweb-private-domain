﻿/* Lithuanian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'lt',
		cancelText: '×',
		cancelTitle:	'Atšaukti',
		hideText: 'Paslėpti',
		tourMapText:'≡',	
		tourMapTitle: 'Žemėlapis',
		nextTextDefault:'Pirmyn',	
		prevTextDefault:'Atgal',	
		endText:'Padaryta',
		contDialogTitle: 'Tęsti nebaigtą kelionė?',
		contDialogContent: 'spauskite "Tęsti" pradėti žingsnis, kuris baigė paskutinį kartą. ',
		contDialogBtnBegin: 'Pradėti nuo pradžių',
		contDialogBtnContinue: 'Tęsti',
		introTitle:'Sveiki atvykę į interaktyvią kelionę.', 							
		introContent:'Šioje kelionėje papasakos apie pagrindines svetainės funkcijas.',	
		introDialogBtnStart:'Pradėti',											
		introDialogBtnCancel:'Atšaukti'
	}
});