﻿/* Croatian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'hr',
		cancelText: '×',
		cancelTitle:	'Otkazati',
		hideText: 'Sakriti',
		tourMapText:'≡',	
		tourMapTitle: 'Obilazak karti',
		nextTextDefault:'Sljedeći',	
		prevTextDefault:'Prijašnji',	
		endText:'Kraj',
		contDialogTitle: 'Nastavi nedovršenu obilazak?',
		contDialogContent: 'Kliknite na "Nastavi" za početak korak na kojem je završio posljednji put.',
		contDialogBtnBegin: 'Počni od početka',
		contDialogBtnContinue: 'Nastavi',
		introTitle:'Dobrodošli na interaktivnu turneju.', 							
		introContent:'Ova turneja će vam reći o glavnim funkcijama web mjesta.',	
		introDialogBtnStart:'Početak',											
		introDialogBtnCancel:'Otkazati'
	}
});