﻿/* Slovak Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'sk',
		cancelText: '×',
		cancelTitle:	'Zrušiť',
		hideText: 'skryť',
		tourMapText:'≡',	
		tourMapTitle: 'Mapa prehliadky',
		nextTextDefault:'Ďalšie',	
		prevTextDefault:'Späť',	
		endText:'koniec tour',
		contDialogTitle: 'Pokračujte nedokončený turné?',
		contDialogContent: 'kliknite na "Continue" spustíte krokom, na ktorom skončil minule.',
		contDialogBtnBegin: 'Začnite od začiatku',
		contDialogBtnContinue: 'Pokračovať',
		introTitle:'Vitajte na interaktívnej turné.', 							
		introContent:'Toto prehliadka vám povie o hlavných funkciách lokality.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Zrušiť'
	}
});