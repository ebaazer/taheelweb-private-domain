﻿/* Tajiki Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'tj',
		cancelText: '×',
		cancelTitle: 'Бекор кардан',
		hideText: 'Пинҳон кардан',
		tourMapText:'≡',	
		tourMapTitle: 'Харитаи саёҳат',
		nextTextDefault:'Баъдӣ',	
		prevTextDefault:'Гузашта',	
		endText:'Анҷоми саёҳат',
		contDialogTitle: 'Идома сафари нотамом? ',
		contDialogContent: 'тугмаи "Идома", кунед барои давом',
		contDialogBtnBegin: 'Оғози аз аввали ',
		contDialogBtnContinue: "Идома",
		introTitle:'Ба сайти интерактивӣ хуш омадед', 							
		introContent:'Ин сафари шумо дар бораи функсияҳои асосии сайт нақл мекунад.',	
		introDialogBtnStart:'Оғоз кунед',											
		introDialogBtnCancel:'Бекор кардан'
	}
});