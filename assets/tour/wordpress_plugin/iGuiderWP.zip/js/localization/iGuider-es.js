﻿/* Spanish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'es',
		cancelTitle: 'Cancelar',
		cancelText: '×',
		hideText: 'Ocultar',
		tourMapText:'≡',
		tourMapTitle: 'Mapa del gira',
		nextTextDefault:'Sig',
		prevTextDefault:'Ant',
		endText:'Fin',
		contDialogTitle:'Continuación del recorrido sin terminar?',
		contDialogContent:'Haga clic en "Continuar" para comenzar con la etapa en la que terminó la última vez.',
		contDialogBtnBegin:'Comience de nuevo',
		contDialogBtnContinue:'Continuar',
		introTitle:'Bienvenido a la gira interactiva',
		introContent:'Esta gira le informará sobre las funcionalidades principales del sitio',
		introDialogBtnStart:'Start',															
		introDialogBtnCancel:'Cancelar'
	}
});