﻿/* Danish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'da',
		cancelText: '×',
		cancelTitle: 'Ophæve',
		hideText: 'Skjule',
		tourMapText:'≡',
		tourMapTitle: 'Tour of kortet',
		nextTextDefault:'Næste',
		prevTextDefault:'Tidligere',
		endText:'Ende',
		contDialogTitle:'Fortsæt det ufærdige tur?',
		contDialogContent:'Klik på "Fortsæt" for at starte med trin, som sluttede sidste gang.',
		contDialogBtnBegin:'Start fra begyndelsen',
		contDialogBtnContinue:'Fortsæt',
		introTitle:'Velkommen til den interaktive tur.', 							
		introContent:'Denne tour vil fortælle dig om de vigtigste funktioner.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Afbestille'
	}
});