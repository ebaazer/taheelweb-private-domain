﻿/* Vietnamese Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'vi',
		cancelText: '×',
		cancelTitle: 'Hủy bỏ',
		hideText: 'Ẩn giấu',
		tourMapText:'≡',	
		tourMapTitle: 'Tour du lịch Bản đồ',
		nextTextDefault:'Kế tiếp',	
		prevTextDefault:'Trước',	
		endText:'Kết thúc tour',
		contDialogTitle: 'Tiếp tục các tour du lịch chưa hoàn thành? ',
		contDialogContent: 'Nhấp vào "Tiếp tục" để bắt đầu với các bước trên mà kết thúc thời gian qua. ',
		contDialogBtnBegin: 'Bắt đầu từ đầu',
		contDialogBtnContinue: 'Tiếp tục',
		introTitle:'Chào mừng bạn đến với chuyến tham quan tương tác.', 							
		introContent:'Chuyến đi này sẽ cho bạn biết về các chức năng của trang web chính.',	
		introDialogBtnStart:'Khởi đầu',											
		introDialogBtnCancel:'Huỷ'
	}
});