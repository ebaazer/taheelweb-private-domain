﻿/* Japanese Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ja',
		cancelText: '×',
		cancelTitle:	'キャンセル',
		hideText: '隠す',
		tourMapText:'≡',	
		tourMapTitle: 'ツアーの地図',
		nextTextDefault:'次 &#x3E;',	
		prevTextDefault:'&#x3C; 前',	
		endText:'エンドツアー',
		contDialogTitle:'未完成のツアーを続行しますか？',
		contDialogContent:'クリックしてその上に最後の時間を終えた段階で開始するには、「続行」。',
		contDialogBtnBegin:'最初から開始します',
		contDialogBtnContinue:'持続する',
		introTitle:'インタラクティブツアーへようこそ', 							
		introContent:'このツアーでは、メインサイトの機能について説明します',	
		introDialogBtnStart:'開始',											
		introDialogBtnCancel:'キャンセル'
	}
});