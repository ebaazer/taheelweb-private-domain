﻿/* Arabic Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ar',
		cancelTitle: 'إلغاء',
		cancelText: '×',
		hideText: 'إخفاء',
		tourMapText:'≡',
		tourMapTitle: 'خريطة جولة',
		nextTextDefault:'التالي',
		prevTextDefault:'السابق',
		endText:'نهاية',
		contDialogTitle:'تستمر الجولة لم تنته؟',
		contDialogContent:'انقر على "متابعة" لبدء بالخطوة التي أنهى آخر مرة.',
		contDialogBtnBegin:'نبدأ من البداية',
		contDialogBtnContinue:'استمر',
		introTitle:'مرحبا بكم في جولة تفاعلية',
		introContent:'هذه الجولة سوف اقول لكم عن وظائف الموقع الرئيسي',
		introDialogBtnStart:'بداية',															
		introDialogBtnCancel:'إلغاء'
	}
});