﻿/* Basque Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'eu',
		cancelText: '×',
		cancelTitle:	'Utzi',
		hideText: 'Ezkutatu',
		tourMapText:'≡',	
		tourMapTitle: 'Tour mapa',
		nextTextDefault:'Hur',	
		prevTextDefault:'Aur',	
		endText:'Amaiera',
		contDialogTitle: 'bukatu gabe tour Jarraitu?',
		contDialogContent: 'sakatu "Jarraitu" urrats bertan amaitu azken aldia hasiko da.',
		contDialogBtnBegin: 'Hasi hasieratik',
		contDialogBtnContinue: 'Jarraitu'		,
		introTitle:'Ongi etorri bira interaktiboa egiteko.', 							
		introContent:'Bira honek funtzionalitate nagusien berri emango dizu.',	
		introDialogBtnStart:'Hasi',											
		introDialogBtnCancel:'Utzi'
	}
});