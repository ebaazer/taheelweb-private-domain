﻿/* Romanian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ro',
		cancelText: '×',
		cancelTitle:	'Închide',
		hideText: 'Ascunde',
		tourMapText:'≡',	
		tourMapTitle: 'Harta tur',
		nextTextDefault:'Luna următoare',	
		prevTextDefault:'Luna precedentă',	
		endText:'Tur end',
		contDialogTitle: 'Continuarea turului neterminat? ',
		contDialogContent: 'Faceți clic pe "Continuați" pentru a începe cu pasul pe care a terminat ultima oară.',
		contDialogBtnBegin: 'Începe de la început',
		contDialogBtnContinue: 'Continuați',
		introTitle:'Bine ați venit la turul interactiv.', 							
		introContent:'Acest tur va va spune despre principalele funcționalități ale site-ului.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Anulare'
	}
});