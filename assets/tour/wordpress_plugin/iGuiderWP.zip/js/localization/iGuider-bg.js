﻿/* Bulgarian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'bg',
		cancelText: '×',
		cancelTitle:	'Отмени',
		hideText: 'Крия',
		tourMapText:'≡',
		tourMapTitle: 'Обиколка Карта',
		nextTextDefault:'Напред',
		prevTextDefault:'Назад',
		endText:'Завършеност',
		contDialogTitle:'Продължи недовършената турнето?',
		contDialogContent:'Натиснете "Продължи", за да започнете със стъпка, на която завърши последен път.',
		contDialogBtnBegin:'Започнете от началото',
		contDialogBtnContinue:'Продължи',
		introTitle:'Добре дошли в интерактивното турне.', 							
		introContent:'Тази обиколка ще ви разкаже за основните функционалности на сайта.',	
		introDialogBtnStart:'Започнете',											
		introDialogBtnCancel:'Отказ'
	}
});