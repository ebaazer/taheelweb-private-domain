﻿/* Catalan Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ca',
		cancelText: '×',
		cancelTitle: 'Cancel·la la gira',
		hideText: 'Amagar',
		tourMapText:'≡',
		tourMapTitle: 'Mapa del Gira',
		nextTextDefault:'Següent',
		prevTextDefault:'Anterior',
		endText:'final',
		contDialogTitle:'Continuació del recorregut sense acabar?',
		contDialogContent:'Feu clic a "Continua" per començar amb l\'etapa en la qual va acabar l\'última vegada.',
		contDialogBtnBegin:'Començar des del principi',
		contDialogBtnContinue:'Continua',
		introTitle:'Benvingut a la gira interactiva', 							
		introContent:'Aquest recorregut us explicarà sobre les funcionalitats principals del lloc',	
		introDialogBtnStart:'Començar',											
		introDialogBtnCancel:'Cancel · lar'
	}
});