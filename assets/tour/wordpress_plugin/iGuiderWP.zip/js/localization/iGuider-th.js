﻿/* Thai Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'th',
		cancelText: '×',
		cancelTitle:	'ปิด',
		hideText: 'ปิดบัง',
		tourMapText:'≡',	
		tourMapTitle: 'ทัวร์กะรัต',
		nextTextDefault:'ถัดไป',	
		prevTextDefault:'ย้อน',	
		endText:'ปลาย',
		contDialogTitle: 'ดำเนินการต่อทัวร์ยังไม่เสร็จ?',
		contDialogContent: 'คลิก "ดำเนินการต่อ" เพื่อเริ่มต้นด้วยขั้นตอนที่เสร็จเป็นครั้งสุดท้าย.',
		contDialogBtnBegin: 'เริ่มต้นจากจุดเริ่มต้น',
		contDialogBtnContinue: 'ดำเนินต่อไป',
		introTitle:'ยินดีต้อนรับสู่ทัวร์เชิงโต้ตอบ', 							
		introContent:'ทัวร์นี้จะบอกคุณเกี่ยวกับฟังก์ชันการทำงานของเว็บไซต์หลัก',	
		introDialogBtnStart:'เริ่มต้น',											
		introDialogBtnCancel:'ยกเลิก'
	}
});