﻿/* Hebrew Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'he',
		cancelText: '×',
		cancelTitle:	'לְבַטֵל',
		hideText: 'להתחבא',
		tourMapText:'≡',	
		tourMapTitle: 'סיור המפה',
		nextTextDefault:'הַבָּא',	
		prevTextDefault:'קודם',	
		endText:'סוֹף',
		contDialogTitle: 'המשך הסיור הגמור?',
		contDialogContent: 'לחץ על "המשך" כדי להתחיל עם צעד שעליו סיים בפעם אחרונה.',
		contDialogBtnBegin: 'התחל בהתחלה',
		contDialogBtnContinue: 'על \'המשך',
		introTitle:'ברוכים הבאים לסיור האינטראקטיבי.', 							
		introContent:'סיור זה יספר לכם על הפונקציות העיקריות של האתר.',	
		introDialogBtnStart:'הַתחָלָה',											
		introDialogBtnCancel:'לְבַטֵל'
	}
});