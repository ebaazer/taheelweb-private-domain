﻿/* Welsh Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'cy',
		cancelText: '×',
		cancelTitle: 'Diddymu',
		hideText: 'Cuddio',
		tourMapText:'≡',
		tourMapTitle: 'Taith o amgylch map',
		nextTextDefault:'Nesaf',
		prevTextDefault:'Blaenorol',
		endText:'Diwedd',
		contDialogTitle:'Parhau â\'r daith heb ei orffen?',
		contDialogContent:'Cliciwch ar "Parhau" i ddechrau gyda cam y mae orffen tro diwethaf.',
		contDialogBtnBegin:'Dechrau o\'r dechrau',
		contDialogBtnContinue:'Parhau',
		introTitle:'Croeso i\'r daith ryngweithiol.', 							
		introContent:'Bydd y daith hon yn dweud wrthych am brif swyddogaeth y wefan',	
		introDialogBtnStart:'Dechrau',											
		introDialogBtnCancel:'Diddymu'
	}
});