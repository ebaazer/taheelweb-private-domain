﻿/* Galician Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'gl',
		cancelText: '×',
		cancelTitle:	'Cancelar',
		hideText: 'Ocultar',
		tourMapText:'≡',	
		tourMapTitle: 'Posto de mapa',
		nextTextDefault:'Seguinte',	
		prevTextDefault:'Anterior',	
		endText:'Final',
		contDialogTitle: 'Continuar o paseo inacabado?',
		contDialogContent: 'Prema en "Continuar" para iniciar a etapa na que terminou a última vez.',
		contDialogBtnBegin: 'Comezar do comezo',
		contDialogBtnContinue: 'Continuar',
		introTitle:'Benvido á xira interactiva.', 							
		introContent:'Este percorrido contará sobre as funcionalidades do sitio principal.',	
		introDialogBtnStart:'Comezar',											
		introDialogBtnCancel:'Cancelar'
	}
});