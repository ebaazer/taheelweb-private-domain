﻿/* Hindi Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'hi',
		cancelText: '×',
		cancelTitle:	'रद्द करना',
		hideText: 'छिपाना',
		tourMapText:'≡',	
		tourMapTitle: 'नक्शे के टूर',
		nextTextDefault:'अगला',	
		prevTextDefault:'पिछला',	
		endText:'समाप्त',
		contDialogTitle: 'जारी अधूरा टूर?',
		contDialogContent: '"जारी रखें" पर क्लिक कदम है जिस पर पिछले समय समाप्त के साथ शुरू करने के लिए।',
		contDialogBtnBegin: 'शुरू से ही शुरू करें',
		contDialogBtnContinue: 'जारी रखें',
		introTitle:'इंटरैक्टिव टूर में आपका स्वागत है', 							
		introContent:'यह दौरा आपको मुख्य साइट के कार्यात्मकताओं के बारे में बताएगा।',	
		introDialogBtnStart:'प्रारंभ।',											
		introDialogBtnCancel:'रद्द करना।'
	}
});