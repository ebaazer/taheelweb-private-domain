﻿/* Swedish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'sv',
		cancelText: '×',
		cancelTitle:	'Abort',
		hideText: 'Dölja',
		tourMapText:'≡',	
		tourMapTitle: 'Karats tur',
		nextTextDefault:'Följande',	
		prevTextDefault:'Föregående',	
		endText:'Fullständig',
		contDialogTitle: 'Fortsätt den ofärdiga tur?',
		contDialogContent: 'Klicka på "Fortsätt" för att starta med steg som slutade förra gången.',
		contDialogBtnBegin: 'Starta från början',
		contDialogBtnContinue: 'Fortsätt',
		introTitle:'Välkommen till den interaktiva turnén.', 							
		introContent:'Denna turné kommer att berätta om de viktigaste funktionerna på webbplatsen.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Annullera'
	}
});