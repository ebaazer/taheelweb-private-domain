﻿/* Georgian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ka',
		cancelText: '×',
		cancelTitle:	'გაუქმება',
		hideText: 'დამალვა',
		tourMapText:'≡',	
		tourMapTitle: 'რუკა ტური',
		nextTextDefault:'შემდეგი',	
		prevTextDefault:'წინა',	
		endText:'ბოლოს ტური',
		contDialogTitle: 'გაგრძელება დაუმთავრებელი ტური?',
		contDialogContent: 'დაკლიკეთ "გაგრძელება" უნდა დაიწყოს ნაბიჯი, რომელიც დასრულდა ბოლო დროს.',
		contDialogBtnBegin: 'დაწყება თავიდან',
		contDialogBtnContinue: 'გაგრძელება',
		introTitle:'მოგესალმებით ინტერაქტიული ტური.', 							
		introContent:'ეს ტური გეტყვით ძირითადი საიტის ფუნქციონალზე.',	
		introDialogBtnStart:'დაწყება',											
		introDialogBtnCancel:'გაუქმება'
	}
});