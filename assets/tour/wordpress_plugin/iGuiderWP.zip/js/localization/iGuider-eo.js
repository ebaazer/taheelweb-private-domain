﻿/* Esperanto Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'eo',
		cancelText: '×',
		cancelTitle:	'Nuligi',
		hideText: 'Kaŝi',
		tourMapText:'≡',	
		tourMapTitle: 'Tour de mapo',
		nextTextDefault:'Sekva',	
		prevTextDefault:'Antaŭa',	
		endText:'Fino',
		contDialogTitle:'Daŭrigi la nefinita ĝiras?',
		contDialogContent:'Klaku "Daŭrigu" por komenci kun paŝo sur kiu finis lastan fojon.',
		contDialogBtnBegin:'Komenci de komenco',
		contDialogBtnContinue:'Daŭrigu',
		introTitle:'Bonvenon al la interaga ĝiras.', 							
		introContent:'Ĉi tiu turneo rakontos al vi pri la ĉefaj retejoj.',	
		introDialogBtnStart:'Komencu',											
		introDialogBtnCancel:'Nuligi'
	}
});