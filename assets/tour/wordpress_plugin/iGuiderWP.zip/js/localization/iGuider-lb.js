﻿/* Luxembourgish Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'lb',
		cancelText: '×',
		cancelTitle:	'Fäerdeg',
		hideText: 'Verstoppen',
		tourMapText:'≡',	
		tourMapTitle: 'Kaart vum Tour',
		nextTextDefault:'Weider',	
		prevTextDefault:'Zréck',	
		endText:'Enn Tour',
		contDialogTitle: 'Continue der serbesch Tour?',
		contDialogContent: 'Klick "Continue" mat Schrëtt ze Start op déi lescht Zäit fäerdeg.',
		contDialogBtnBegin: 'vum Ufank Start',
		contDialogBtnContinue: 'Continue',
		introTitle:'Wëllkomm op der interaktiver Tour.', 							
		introContent:'Dëse Tour informéiert Iech iwwer d\'Haaptfunktiounen.',	
		introDialogBtnStart:'Start',											
		introDialogBtnCancel:'Ofbriechen'
	}
});