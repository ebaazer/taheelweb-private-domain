﻿/* Hungarian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'hu',
		cancelText: '×',
		cancelTitle: 'Mégsem',
		hideText: 'Elrejt',
		tourMapText:'≡',	
		tourMapTitle: 'Térképe túra',
		nextTextDefault:'Előre',	
		prevTextDefault:'Vissza',	
		endText:'Vége túra',
		contDialogTitle: 'Tovább a befejezetlen túra?',
		contDialogContent: 'Kattintson a "Tovább" kezdeni lépést, amely kész utoljára.',
		contDialogBtnBegin: 'Start elejétől',
		contDialogBtnContinue: 'Tovább',
		introTitle:'Üdvözöljük az interaktív túrán.', 							
		introContent:'Ez a turné bemutatja Önt a fő funkciókról.',	
		introDialogBtnStart:'Rajt',											
		introDialogBtnCancel:'Mégsem'
	}
});