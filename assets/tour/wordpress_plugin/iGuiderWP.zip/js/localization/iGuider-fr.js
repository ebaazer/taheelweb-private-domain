﻿/* French Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'fr',
		cancelText: '×',
		cancelTitle:	'Annuler',
		hideText: 'Cacher',
		tourMapText:'≡',	
		tourMapTitle: 'Tour of la carte',
		nextTextDefault:'Suivant',	
		prevTextDefault:'Précédent',	
		endText:'Fin',
		contDialogTitle: 'Continuer la visite inachevée?',
		contDialogContent: 'Cliquez sur "Continuer" pour commencer à l\'étape sur laquelle a terminé la dernière fois.',
		contDialogBtnBegin: 'Début du début',
		contDialogBtnContinue: 'Continuer',
		introTitle:'Bienvenue à la visite interactive.', 							
		introContent:'Cette visite vous parlera des fonctionnalités principales du site.',	
		introDialogBtnStart:'Début',											
		introDialogBtnCancel:'Annuler'
	}
});