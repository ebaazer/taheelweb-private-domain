﻿/* Italian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'it',
		cancelText: '×',
		cancelTitle:	'Annulla',
		hideText: 'nascondere',
		tourMapText:'≡',	
		tourMapTitle: 'Mappa di giro',
		nextTextDefault:'Prec',	
		prevTextDefault:'Succ',	
		endText:'Fatto',
		contDialogTitle: 'Continua il tour non finito?',
		contDialogContent: 'Fare clic su "Continua" per iniziare con il passo che si è conclusa l\'ultima volta.',
		contDialogBtnBegin: 'Comincia dall\'inizio',
		contDialogBtnContinue: 'Continua',
		introTitle:'Benvenuti nel tour interattivo.', 							
		introContent:'Questo tour ti parlerà delle funzionalità del sito principale.',	
		introDialogBtnStart:'Inizio',											
		introDialogBtnCancel:'Annulla'
	}
});