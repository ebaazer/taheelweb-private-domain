﻿/* Serbian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'sr',
		cancelText: '×',
		cancelTitle: 'Прекид',
		hideText: 'Сакрити',
		tourMapText:'≡',	
		tourMapTitle: 'Карат турнеја',
		nextTextDefault:'Следећи',	
		prevTextDefault:'Претходна',	
		endText:'Комплетан',
		contDialogTitle:'Наставити недовршен турнеју?',
		contDialogContent:'Кликните на "Настави" да се почне са кораком на којима завршио последњи пут.',
		contDialogBtnBegin:'Почните од почетка',
		contDialogBtnContinue:'Настави',
		introTitle:'Добродошли на интерактивну турнеју', 							
		introContent:'Ова тура ће вам рећи о функцијама главног сајта',	
		introDialogBtnStart:'Почетак',											
		introDialogBtnCancel:'Поништити'
	}
});