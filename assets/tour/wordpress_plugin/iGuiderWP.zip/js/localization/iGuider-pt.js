﻿/* Portuguese Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'pt',
		cancelText: '×',
		cancelTitle:	'Fechar',
		hideText: 'Esconder',
		tourMapText:'≡',	
		tourMapTitle: 'Mapa de tour',
		nextTextDefault:'Seguinte',	
		prevTextDefault:'Anterior',	
		endText:'Feito',
		contDialogTitle: 'Continue o passeio inacabado?',
		contDialogContent: 'Clique em "Continuar" para iniciar com a etapa em que terminou a última vez. ',
		contDialogBtnBegin: 'Comece do começo ',
		contDialogBtnContinue: 'Continuar',
		introTitle:'Bem-vindo à turnê interativa', 							
		introContent:'Este passeio irá falar sobre as principais funcionalidades do site.',	
		introDialogBtnStart:'Começar',											
		introDialogBtnCancel:'Cancelar'
	}
});