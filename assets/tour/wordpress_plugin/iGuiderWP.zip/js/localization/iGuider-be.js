﻿/* Belarusian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'be',
		cancelText: '×',
		cancelTitle: 'Адмяніць',
		hideText: 'Схаваць',
		tourMapText:'≡',
		tourMapTitle: 'Карта тура',
		nextTextDefault:'Наст.',
		prevTextDefault:'Папяр.',
		endText:'Скончыць',
		contDialogTitle:'Працягнуць няскончаную тур?',
		contDialogContent:'Націсніце кнопку "Працягнуць", каб пачаць з этапу, на якім скончылі ў мінулы раз.',
		contDialogBtnBegin:'Пачаць з пачатку',
		contDialogBtnContinue:'Працягнуць',
		introTitle:'Сардэчна запрашаем у інтэрактыўны тур', 							
		introContent:'Гэты тур раскажа вам аб асноўных функцыянальных магчымасцяў сайта.',	
		introDialogBtnStart:'Старт',											
		introDialogBtnCancel:'Адмена'
	}
});