﻿/* Estonian Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'et',
		cancelText: '×',
		cancelTitle:	'Tühistama',
		hideText: 'Varjama',
		tourMapText:'≡',	
		tourMapTitle: 'Tour of kaart',
		nextTextDefault:'Järgmine',	
		prevTextDefault:'Eelmine',	
		endText:'Lõpp',
		contDialogTitle: 'Jätka lõpetamata tour?',
		contDialogContent: 'klõpsake "Jätka" alustada samm, mis valmis viimane kord.',
		contDialogBtnBegin: 'Alusta algusest',
		contDialogBtnContinue: 'Jätka',
		introTitle:'Tere tulemast interaktiivsele ekskursioonile.', 							
		introContent:'See ekskursioon ütleb teile põhisaitide funktsioone.',	
		introDialogBtnStart:'Alusta',											
		introDialogBtnCancel:'Loobu'
	}
});