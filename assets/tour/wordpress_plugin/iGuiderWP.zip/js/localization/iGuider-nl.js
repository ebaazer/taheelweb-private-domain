﻿/* Dutch Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'nl',
		cancelText: '×',
		cancelTitle:	'Annuleer',
		hideText: 'Verbergen',
		tourMapText:'≡',	
		tourMapTitle: 'Kaart',
		nextTextDefault:'Volgende',	
		prevTextDefault:'Voorgaand',	
		endText:'Gedaan',
		contDialogTitle:'Ga door het onvoltooide tour?',
		contDialogContent:'Klik op "Doorgaan" om te beginnen met de stap die eindigde vorige keer.',
		contDialogBtnBegin:'Start vanaf het begin',
		contDialogBtnContinue:'Doorgaan',
		introTitle:'Welkom bij de interactieve tour.', 							
		introContent:'Deze rondleiding vertelt u over de belangrijkste sitefunctionaliteiten.',	
		introDialogBtnStart:'Begin',											
		introDialogBtnCancel:'Annuleer'
	}
});