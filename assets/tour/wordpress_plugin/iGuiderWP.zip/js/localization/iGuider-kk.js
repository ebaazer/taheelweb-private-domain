﻿/* Kazakh Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'kk',
		cancelText: '×',
		cancelTitle:	'Күшін жою',
		hideText: 'Жасыру',
		tourMapText:'≡',	
		tourMapTitle: 'Тур картасы',
		nextTextDefault:'Келесі',	
		prevTextDefault:'Алдыңғы',	
		endText:'Дайын',
		contDialogTitle: 'Аяқталмаған тур Жалғастыру?',
		contDialogContent: 'соңғы рет аяқталды онда қадамынан бастаңыз үшін "Жалғастыру" батырмасын басыңыз.',
		contDialogBtnBegin: 'басынан бастау',
		contDialogBtnContinue: 'Жалғастыру',
		introTitle:'Интерактивті турға қош келдіңіз.', 							
		introContent:'Бұл тур сізге негізгі тораптың функционалдық мүмкіндіктері туралы айтып береді.',	
		introDialogBtnStart:'Бастау',											
		introDialogBtnCancel:'Болдырмау'
	}
});