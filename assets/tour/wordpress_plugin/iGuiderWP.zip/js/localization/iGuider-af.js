﻿/* Afrikaans Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'af',
		cancelText: '×',
		cancelTitle: 'Kanselleer',
		hideText: 'Verberg',
		tourMapText:'≡',
		tourMapTitle: 'Kaart van toer',
		nextTextDefault:'Volgende',
		prevTextDefault:'Vorige',
		endText:'Einde',
		contDialogTitle:'Gaan voort met die onvoltooide toer?',
		contDialogContent:'Klik op "Gaan voort" om te begin met stap waarop klaar laaste keer.',
		contDialogBtnBegin:'Begin van die begin',
		contDialogBtnContinue:'Gaan voort',
		introTitle:'Welkom by die interaktiewe toer.', 							
		introContent:'Hierdie toer sal jou vertel van die belangrikste funksies.',	
		introDialogBtnStart:'Begin',											
		introDialogBtnCancel:'Kanselleer'
	}
});