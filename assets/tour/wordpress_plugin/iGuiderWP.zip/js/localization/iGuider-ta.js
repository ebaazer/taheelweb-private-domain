﻿/* Tamil Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ta',
		cancelText: '×',
		cancelTitle:	'கைவிடு',
		hideText: 'மறை',
		tourMapText:'≡',	
		tourMapTitle: 'காரத் சுற்றுப்பயணம்',
		nextTextDefault:'பின்வரும்',	
		prevTextDefault:'முந்தைய',	
		endText:'இறுதியில்',
		contDialogTitle: 'முடிவுறாத உலாவைத் தொடர்க? ',
		contDialogContent: '"தொடர்ந்து" என்பதை கிளிக் செய்யவும் கடந்த முறை முடிந்ததும் இது படி தொடங்க.',
		contDialogBtnBegin: 'ஆரம்பத்தில் இருந்து தொடங்க',
		contDialogBtnContinue: 'தொடரவும்',
		introTitle:'ஊடாடும் சுற்றுலாக்கு வரவேற்கிறோம்', 							
		introContent:'இந்த சுற்றுப்பயணம், பிரதான தள செயல்பாடுகள் பற்றி உங்களுக்கு தெரிவிக்கும்',	
		introDialogBtnStart:'தொடங்குங்கள்',											
		introDialogBtnCancel:'ரத்து'
	}
});