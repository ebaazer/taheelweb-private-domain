﻿/* Malayalam Translation for the iGuider plugin. */
jQuery(function($){
	$.iGuiderLang = {
		lang:'ml',
		cancelText: '×',
		cancelTitle:	'റദ്ദാക്കുക',
		hideText: 'മറയ്ക്കുക',
		tourMapText:'≡',	
		tourMapTitle: 'ടൂർ മാപ്പ്',
		nextTextDefault:'അടുത്തത്',	
		prevTextDefault:'മുമ്പത്തെ',	
		endText:'ഒപ്പം',
		contDialogTitle:'പൂർത്തിയാകാത്ത ടൂർ തുടരണോ?',
		contDialogContent:'ക്ലിക്ക് "തുടരുക" കഴിഞ്ഞ തവണ പൂർത്തിയാക്കി ഏത് ഘട്ടം ആരംഭിക്കാൻ.',
		contDialogBtnBegin:'തുടക്കത്തിൽ നിന്ന് ആരംഭിക്കാൻ',
		contDialogBtnContinue:'തുടരുക',
		introTitle:'ഇന്ററാക്ടീവ് ടൂർയിലേക്ക് സ്വാഗതം', 							
		introContent:'ഈ ടൂർ പ്രധാന സൈറ്റ് പ്രവർത്തനങ്ങളെക്കുറിച്ച് നിങ്ങൾക്ക് അറിയിക്കും',	
		introDialogBtnStart:'ആരംഭിക്കുക',											
		introDialogBtnCancel:'റദ്ദാക്കുക'
	}
});